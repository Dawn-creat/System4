from aiohttp import web
from cryptography.fernet import InvalidToken
from cryptography.fernet import Fernet
from pathlib import Path
import jinja2
home_path = Path(__file__).parent
jinja_env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(home_path)))
secret_key = Fernet.generate_key()
fernet = Fernet(secret_key)
print(f"Generated Secure Key: {secret_key}")
from dbconn import db_block

async def start(request):
    return web.Response(text="""
<html>
    <head>
		<meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
        <style>
            img{
                display:None
            }
        </style>
    </head>
    <body>
        <section>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            <div class="users">
                <ul class="list1">
                    <li><a href="/login2"><button class="stu">学生</button></a></li>
                    <li><a href="/login3"><button class="stu">教师</button></a></li>
                    <li><a href="/login1"><button class="stu">管理者</button></a></li>
                </ul>
            </div>
            </div>

        </section>
    </body>
</html>""",content_type="text/html")

#教学管理者
passwords = {"tom": "123"}
async def ans1(request):
    user = get_current_user(request)
    if not user:
        return web.HTTPFound('/login1')

    return web.Response(text=f"""
<html>
    <head>
		<meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>    
    <body>
        
        <section>
            <div class="hello">
                <h3> Hello, {user}</h3>
                <form action="/logout1" method="post">
                    <input type="submit" value="Sign out">
                </form>
            </div>
            <div class="button2">
                <ul class="list1">
                    <li><a href="/course1"><button class="sel_button">课程计划</button></a></li>
                    <li><a href="/grade1"><button class="sel_button"> 班级成绩</button>></a></li>
                </ul>
            </div>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            </div>
        </section>   
    </body>
</html>
    """, content_type="text/html")


async def login_page1(request):
    return web.Response(text=f"""
<html>
    <head>
        <meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>
    <body>        
        <section>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            </div>
            <div class="form1">
                <form action="/login1" method="post">
                    UserName: <input type="text" name="username">
                    Password: <input type="password" name="password">
                    <input type="submit" value="Sign in">
                </form>
            </div>
        </section>
    </body>
</html>
    """, content_type="text/html")



async def handle_login1(request):
    parmas = await request.post()  # 获取POST请求的表单字段数据
    username = parmas.get("username")
    password = parmas.get("password")

    if passwords.get(username) != password:  # 比较密码
        return web.HTTPFound('/login1')  # 比对失败重新登录

    resp = web.HTTPFound('/a1')
    set_secure_cookie(resp, "session_id", username)
    return resp

async def handle_logout1(request):
    resp = web.HTTPFound('/login1')
    resp.del_cookie("session_id")
    return resp


def get_current_user(request):
    user_id = get_secure_cookie(request, "session_id")
    return user_id


def get_secure_cookie(request, name):
    value = request.cookies.get(name)
    if value is None:
        return None

    try:
        buffer = value.encode('utf-8')  # 将文本转换成字节串
        buffer = fernet.decrypt(buffer)
        secured_value = buffer.decode('utf-8')  # 将加密的字节串转换成文本
        return secured_value
    except InvalidToken:
        print("Cannot decrypt cookie value")
        return None


def set_secure_cookie(response, name, value, **kwargs):
    value = fernet.encrypt(value.encode('utf-8')).decode('utf-8')
    response.set_cookie(name, value, **kwargs)

#第一学期成绩表
async def list_grade1(request):
    with db_block() as db:
        db.execute('''
        SELECT student.name, g.grade1, g.grade2, g.grade3, g.grade4, g.grade5 
        FROM course_grade as g, student
        WHERE student.sn = g.stu_sn
        ''')

        items = [tuple(row) for row in db]

    template = jinja_env.get_template('list.html')
    return web.Response(text=template.render(items=items),
                        content_type="text/html")
#第二学期成绩表
async def list_grade2(request):
    with db_block() as db:
        db.execute('''
        SELECT student.name, g.grade1, g.grade2, g.grade3, g.grade4, g.grade5 
        FROM course_grade1 as g, student
        WHERE student.sn = g.stu_sn
        ''')

        items3 = [tuple(row) for row in db]

    template = jinja_env.get_template('list.html')
    return web.Response(text=template.render(items3=items3),
                        content_type="text/html")

#教学管理者课表
async def course_list(request):
    return web.Response(text="""
<html>
    <head>
        <meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>
    <body>
        <section>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            <div class="button2">
                <ul class="list1">
                    <li>
                        <a href="/course01"><button class="sel_button">信息1901</button></a>
                        <a href="/course02"><button class="sel_button">工业1901</button></a>
                    </li>
                </ul>
            </div>                
            </div>

    </body>
</html>""",content_type="text/html")

async def course1(request):
    with db_block() as db:
        db.execute('''
        SELECT course1.term1, course1.term2 
        FROM course1
        
        ''')

        items1 = [tuple(row) for row in db]

    template = jinja_env.get_template('course_list1.html')
    return web.Response(text=template.render(items1=items1),
                        content_type="text/html")

async def course2(request):
    with db_block() as db:
        db.execute('''
        SELECT course2.term1, course2.term2 
        FROM course2
        
        ''')

        items2 = [tuple(row) for row in db]

    template = jinja_env.get_template('course_list2.html')
    return web.Response(text=template.render(items2=items2),
                        content_type="text/html")

#学生
passwords1 = {"James": "0305"}
#登录界面
async def login_page2(request):
    return web.Response(text=f"""
<html>
    <head>
        <meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>
    <body>        
        <section>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            </div>
            <div class="form1">
                <form action="/login2" method="post">
                    UserName: <input type="text" name="username">
                    Password: <input type="password" name="password">
                    <input type="submit" value="Sign in">
                </form>
            </div>
        </section>
    </body>
</html>
    """, content_type="text/html")
#登入界面
async def ans2(request):
    user = get_current_user(request)
    if not user:
        return web.HTTPFound('/login2')

    return web.Response(text=f"""
<html>
    <head>
		<meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>    
    <body>
        
        <section>
            <div class="hello">
                <h3> Hello, {user}</h3>
                <form action="/logout2" method="post">
                    <input type="submit" value="Sign out">
                </form>
            </div>
            <div class="button2">
                <ul class="list1">
                    <li><a href="/sc1"><button class="sel_button">第一学期</button></a></li>
                    <li><a href="/sc2"><button class="sel_button">第二学期</button></a></li>
                </ul>
            </div>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            </div>
        </section>   
    </body>
</html>
    """, content_type="text/html")

#验证密码
async def handle_login2(request):
    parmas = await request.post()  # 获取POST请求的表单字段数据
    username = parmas.get("username")
    password = parmas.get("password")

    if passwords1.get(username) != password:  # 比较密码
        return web.HTTPFound('/login2')  # 比对失败重新登录

    resp = web.HTTPFound('/a2')
    set_secure_cookie(resp, "session_id", username)
    return resp
#登出
async def handle_logout2(request):
    resp = web.HTTPFound('/login2')
    resp.del_cookie("session_id")
    return resp
#导入课表1
async def stu_course1(request):
    with db_block() as db:
        db.execute('''
        SELECT sc1.Monday,sc1.Tuesday,sc1.Wednesday,sc1.Thursday,sc1.Friday 
        FROM stu_course1 as sc1

        
        ''')

        items4 = [tuple(row) for row in db]

    template = jinja_env.get_template('sc1.html')
    return web.Response(text=template.render(items4=items4),
                        content_type="text/html")
#导入课表2
async def stu_course2(request):
    with db_block() as db:
        db.execute('''
        SELECT sc2.Monday,sc2.Tuesday,sc2.Wednesday,sc2.Thursday,sc2.Friday 
        FROM stu_course2 as sc2

        
        ''')

        items5 = [tuple(row) for row in db]

    template = jinja_env.get_template('sc2.html')
    return web.Response(text=template.render(items5=items5),
                        content_type="text/html")

#教师
passwords2 = {"joe":"666"}
#登录界面
async def login_page3(request):
    return web.Response(text=f"""
<html>
    <head>
        <meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>
    <body>        
        <section>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            </div>
            <div class="form1">
                <form action="/login3" method="post">
                    UserName: <input type="text" name="username">
                    Password: <input type="password" name="password">
                    <input type="submit" value="Sign in">
                </form>
            </div>
        </section>
    </body>
</html>
    """, content_type="text/html")
#验证密码
async def handle_login3(request):
    parmas = await request.post()  # 获取POST请求的表单字段数据
    username = parmas.get("username")
    password = parmas.get("password")

    if passwords2.get(username) != password:  # 比较密码
        return web.HTTPFound('/login3')  # 比对失败重新登录

    resp = web.HTTPFound('/a3')
    set_secure_cookie(resp, "session_id", username)
    return resp
#登入界面
async def ans3(request):
    user = get_current_user(request)
    if not user:
        return web.HTTPFound('/login3')

    return web.Response(text=f"""
<html>
    <head>
		<meta charset="utf-8" />
		<title>学生管理信息系统</title>
		<link rel="stylesheet" href="./static/style.css" />
    </head>    
    <body>
        
        <section>
            <div class="hello">
                <h3> Hello, {user}</h3>
                <form action="/logout3" method="post">
                    <input type="submit" value="Sign out">
                </form>
            </div>
            <div class="button2">
                <ul class="list1">
                    <li><a href="/tc1"><button class="sel_button">第一学期</button></a></li>
                    <li><a href="/tc2"><button class="sel_button">第二学期</button></a></li>
                </ul>
            </div>
            <!--背景色-->
            <div class="color"></div>
            <div class="color"></div>
            <div class="color"></div>
            <div class="box">
                <!--背景圆-->
                <div class="circle" style="--x:0"></div>
                <div class="circle" style="--x:1"></div>
                <div class="circle" style="--x:2"></div>
                <div class="circle" style="--x:3"></div>
            </div>
        </section>   
    </body>
</html>
    """, content_type="text/html")
#登出
async def handle_logout3(request):
    resp = web.HTTPFound('/login3')
    resp.del_cookie("session_id")
    return resp

#导入课表1
async def tea_course1(request):
    with db_block() as db:
        db.execute('''
        SELECT tc1.Monday,tc1.Tuesday,tc1.Wednesday,tc1.Thursday,tc1.Friday 
        FROM tea_course1 as tc1

        
        ''')

        items7 = [tuple(row) for row in db]

    template = jinja_env.get_template('tc1.html')
    return web.Response(text=template.render(items7=items7),
                        content_type="text/html")

#导入课表2
async def tea_course2(request):
    with db_block() as db:
        db.execute('''
        SELECT tc2.Monday,tc2.Tuesday,tc2.Wednesday,tc2.Thursday,tc2.Friday 
        FROM tea_course2 as tc2

        
        ''')

        items6 = [tuple(row) for row in db]

    template = jinja_env.get_template('tc2.html')
    return web.Response(text=template.render(items6=items6),
                        content_type="text/html")




app = web.Application()
app.router.add_static("/static", home_path / "static")
app.add_routes([
    web.get('/a1', ans1),
    web.get('/login1', login_page1),
    web.post('/login1', handle_login1),
    web.post('/logout1', handle_logout1),
    web.get('/',start),
    web.get('/grade1',list_grade1),
    web.get('/grade2',list_grade2),
    web.get('/course1',course_list),
    web.get('/course01',course1),
    web.get('/course02',course2),
    web.get('/login2',login_page2),
    web.post('/login2',handle_login2),
    web.post('/logout2',handle_logout2),
    web.get('/a2',ans2),
    web.get('/sc1',stu_course1),
    web.get('/sc2',stu_course2),
    web.get('/login3',login_page3),
    web.post('/login3',handle_login3),
    web.get('/a3',ans3),
    web.post('/logout3',handle_logout3),
    web.get('/tc1',tea_course1),
    web.get('/tc2',tea_course2),

    
])


if __name__ == "__main__":
    web.run_app(app, port=8080)