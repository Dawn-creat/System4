DROP TABLE IF EXISTS teacher;
CREATE TABLE IF NOT EXISTS teacher  (
    tn       INTEGER,     --序号
    no      INTEGER, --教师号
    name     TEXT,        --姓名
    gender   CHAR(1),     --性别(F/M/O)
    PRIMARY KEY(tn)
);

-- 给tn创建一个自增序号
CREATE SEQUENCE seq_teacher_tn 
    START 10000 INCREMENT 1 OWNED BY teacher.tn;
ALTER TABLE teacher ALTER tn 
    SET DEFAULT nextval('seq_teacher_tn');
-- 教师号唯一
CREATE UNIQUE INDEX idx_teacher_no ON teacher(no);

-- === 课程表
DROP TABLE IF EXISTS tcourse;
CREATE TABLE IF NOT EXISTS tcourse  (
    tn       INTEGER,     --序号
    no       VARCHAR(10), --课程号
    name     TEXT,        --课程名称
    PRIMARY KEY(tn)
);





