DELETE FROM teacher;
DELETE FROM course;

INSERT INTO teacher (tn, no, name,gender)  VALUES
    (1, 1913610001,  '张老师', '男'),
    (2, 1913610002,  '李老师', '女'), 
    (3, 1913610003,  '王老师', '男'),
    (4, 1913610004,  '马老师', '女');

INSERT INTO tcourse (tn, no, name)  VALUES 
    (1, 'C01',  'Ptython'), 
    (2, 'C02',  '管理统计学'),
    (3, 'C03',  '大数据处理');